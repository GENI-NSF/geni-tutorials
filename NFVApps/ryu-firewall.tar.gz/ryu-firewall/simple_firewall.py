# The code is this file is derived from:
# https://raw.githubusercontent.com/osrg/ryu/master/ryu/app/simple_switch.py
# which is protected by the Apache 2.0 license.
# The modifications are protected by the GENI license.
# Both licenses are included below.
#
# Copyright (C) 2011 Nippon Telegraph and Telephone Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2015 Raytheon BBN Technologies

# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and/or hardware specification (the "Work") to
# deal in the Work without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Work, and to permit persons to whom the Work
# is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Work.

# THE WORK IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE WORK OR THE USE OR OTHER DEALINGS
# IN THE WORK.
"""
An OpenFlow 1.0 Simple Firewall implementation.
"""

import logging
import os
from netaddr import IPAddress as IP 
from netaddr import IPNetwork as Net

from ryu.base import app_manager
from ryu.controller import mac_to_port
from ryu.controller import ofp_event
from ryu.controller import dpset
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_0
from ryu.ofproto import inet
from ryu.ofproto import ether
from ryu.lib.mac import haddr_to_bin
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import tcp
from ryu.lib.packet import udp
from ryu.lib.packet import ipv4

from utils import *

SCRIPT_PATH = os.path.dirname(os.path.abspath(__file__))
config_file = os.path.join(SCRIPT_PATH, "fw.conf")

class SimpleFirewall(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_0.OFP_VERSION]
    
    '''
    firewall_rules stores all permitting connections using four tuples
    <src_ip>[/<netmask>] <src_port> <dst_ip>[/netmask>] <dst_port>
    '''
    def __init__(self, *args, **kwargs):
        super(SimpleFirewall, self).__init__(*args, **kwargs)
        self.firewall_rules = readConfigFile(config_file)
        self.local_net = Net('10.10.1.0/24')

    def add_flow(self, datapath, match, actions, priority=0, idle_timeout=300,  hard_timeout=0):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        mod = parser.OFPFlowMod(datapath=datapath, match=match, actions=actions, priority=priority, 
              idle_timeout=idle_timeout, hard_timeout=hard_timeout, cookie=0, command=ofproto.OFPFC_ADD)
        datapath.send_msg(mod)
    
    '''
    push rules to switch
    for every packet that enters the switch, sent it to controller
    let arp and icmp packets pass directly
    '''
    @set_ev_cls(dpset.EventDP, dpset.DPSET_EV_DISPATCHER)
    def _datapath_handler(self, ev):
        dl_type_arp = 0x0806
        dl_type_ipv4 = 0x0800
        datapath = ev.dp
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        self.logger.info("switch is connected %s", datapath)
        

        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        # add rule for arp packets
        match = parser.OFPMatch(dl_type = dl_type_arp)
        self.add_flow(datapath, match, actions, idle_timeout=0)
        # add rule for ICMP packets
        match = parser.OFPMatch(dl_type = dl_type_ipv4, nw_proto=1)
        self.add_flow(datapath, match, actions, idle_timeout=0)

    '''
    if packet is allowed in the configure file, add a rule in the switch
    that also allows future packets going through the reverse path
    else drop it
    '''
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        
        rule = self.extract_rule(msg)
        if self.check_rule(rule):
            #set rules in the switch
            # if ip.src and ip.dst in the local subnet sent it to NORMAL eels to LOCAL
            match = getFullMatch (msg)
            outport = ofproto.OFPP_NORMAL if self.in_local_subnet(msg,'dst') else ofproto.OFPP_LOCAL
            actions = [parser.OFPActionOutput(outport)]
            self.add_flow(datapath, match, actions)
            #set rules in the switch for reverse path
            reverse_match = getReverseMatch(msg)
            outport = ofproto.OFPP_NORMAL if self.in_local_subnet(msg,'src') else ofproto.OFPP_LOCAL
            actions = [parser.OFPActionOutput(outport)]
            self.add_flow(datapath, reverse_match, actions)
            sendPacketOut(msg=msg, actions=actions, data=msg.data)
        else:
            #set drop rule in the switch
            actions = []
            match = getFullMatch (msg)
            self.add_flow(datapath, match, actions)          

    '''
    check if dst is in local subnet
    '''
    def in_local_subnet(self, msg, who):
       pkt = packet.Packet(msg.data)
       ip_pkt = pkt.get_protocol(ipv4.ipv4)
       if ip_pkt is not None:
           if who == 'dst': 
             if self.local_net.__contains__(IP(ip_pkt.dst)):
               return True
           if who == 'src': 
             if self.local_net.__contains__(IP(ip_pkt.src)):
               return True
           
       return False

    '''
    a connection is defined by a four-tuple rule
    extract the rule from received packet
    '''
    def extract_rule(self, msg):
        pkt = packet.Packet(msg.data)
        rule = { 'sip':None, 'dip':None, 'sport':None, 'dport':None }
        ip_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip_pkt is not None:
            rule['sip'] = ip_pkt.src
            rule['dip'] = ip_pkt.dst
            tcp_pkt = pkt.get_protocol(tcp.tcp)
            udp_pkt = pkt.get_protocol(udp.udp)
            if tcp_pkt is not None:
                rule['sport'] = str(tcp_pkt.src_port)
                rule['dport'] = str(tcp_pkt.dst_port)
            elif udp_pkt is not None:
                rule['sport'] = str(udp_pkt.src_port)
                rule['dport'] = str(udp_pkt.dst_port)
        self.logger.info("Extracted rule %s", rule)
        return rule       
 
    '''
    check if this connection matches any rule in firewall_rules
    ''' 
    def check_rule(self, r):
        # If both the source 
        if (r['sip'] == None or r['dip'] == None):
           self.logger.info("Packet not IPv4 block!")
           return False
        for k,v in self.firewall_rules.items():    
            # check src_ip and dst_ip
            if (r['sip'] == v['sip'] and r['dip'] == v['dip'])            \
            or (IP(r['sip']) in Net(v['sip']) and r['dip'] == v['dip'])   \
            or (r['sip'] == v['sip'] and IP(r['dip']) in Net(v['dip']))   \
            or (IP(r['sip']) in Net(v['sip']) and IP(r['dip']) in Net(v['dip'])):           
                #check src_port and dst_port
                if (v['sport'] == 'any' and v['dport'] == 'any')       \
                or (v['sport'] == 'any' and v['dport'] == r['dport'])  \
                or (v['sport'] == r['sport'] and v['dport'] == 'any')  \
                or (v['sport'] == r['sport'] and v['dport'] == r['dport']): 
                    self.logger.info("Allow Connection rule %s", v)
                    return True
        self.logger.info("Block Connection")
        return False
    
