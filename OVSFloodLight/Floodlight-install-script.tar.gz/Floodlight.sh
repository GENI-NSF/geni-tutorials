#!/bin/bash
git clone http://github.com/floodlight/floodlight
cd floodlight
git submodule init
git submodule update
ant
